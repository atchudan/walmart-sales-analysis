CREATE DATABASE IF NOT EXISTS walmart_sales;
USE walmart_sales;

CREATE TABLE IF NOT EXISTS sales (
    Store          INT,
    Date           DATE,
    Weekly_Sales   FLOAT,
    Holiday_Flag   TINYINT,
    Temperature    FLOAT,
    Fuel_Price     FLOAT,
    CPI            FLOAT,
    Unemployment   FLOAT
);

SET GLOBAL local_infile = 1;

LOAD DATA LOCAL INFILE
  'C:/Users/Sreeram/OneDrive/Desktop/kaggle_datasets/walmart_sales_cleaned_rev.csv'
INTO TABLE sales
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(Store, Date, Weekly_Sales, Holiday_Flag, Temperature, Fuel_Price, CPI, Unemployment);

SHOW GLOBAL VARIABLES LIKE 'local_infile';

select * from sales where store = 1;



select count(*) from sales where store = 1;

select * from sales limit 100;

# total revenue across all the stores
select sum(weekly_sales) as total_revenue from sales ;

# Sales by Store
select store, sum(weekly_sales) as total_sales
from sales
group by store
order by total_sales desc
limit 5;

#Sales Trend Over Time
select date, sum(weekly_sales) as total_sales
from sales
group by date
order by date ;


#impact on holiday sales across all the stores
select holiday_flag , avg(weekly_sales) as avg_sales
from sales
group by holiday_flag;

#sub - holiday_week vs non_holiday across
select store,
sum(case when holiday_flag = 0 then 1 else 0 end) as not_holidays_week,
sum(case when holiday_flag = 1 then 1 else 0 end) as holiday_week
from sales
group by store;


#best and worst weeks

SELECT Date, Weekly_Sales
FROM sales
ORDER BY Weekly_Sales DESC
LIMIT 1;  -- Highest

SELECT Date, Weekly_Sales
FROM sales
ORDER BY Weekly_Sales ASC
LIMIT 1;  -- Lowest

select a.date, a.weekly_sales
from
(
SELECT 
*,
rank() over(order by weekly_sales desc) as sales_rank
FROM sales) a
where a.sales_rank = 1 or a.sales_rank = 6435;

select
date,weekly_sales
from
sales
where weekly_sales = (select max(weekly_sales) from sales) or
weekly_sales = (select min(weekly_sales) from sales);

#Correlation with Fuel Price or Temperature
select fuel_price, round(avg(weekly_sales),2) as avg_sales
from sales
group by fuel_price
order by fuel_price;

select temperature, round(avg(weekly_sales),2) as avg_sales
from sales
group by temperature
order by temperature ;

#How Do CPI and Unemployment Affect Sales?
select 
cpi_rate,
unemployement_rate,
avg_sales
from
(select 
round(cpi,1) as cpi_rate,
round(unemployment,1) as unemployement_rate,
avg(weekly_sales) as avg_sales
from
sales
group by cpi , unemployment) as sales_summary
where avg_sales = 
(
select 
max(avg_sales)
from
(select 
round(cpi,1) as cpi_rate,
round(unemployment,1) as unemployement_rate,
avg(weekly_sales) as avg_sales
from
sales
group by cpi , unemployment) as max_sub
)
or avg_sales =
(select min(avg_sales) 
from
(select 
round(cpi,1) as cpi_rate,
round(unemployment,1) as unemployement_rate,
avg(weekly_sales) as avg_sales
from
sales
group by cpi , unemployment) as min_sub
)
;
# same code using cte
with cte as 
(
select 
round(cpi,1) as cpi_rate,
round(unemployment,1) as unemployement_rate,
avg(weekly_sales) as avg_sales
from
sales
group by cpi_rate , unemployment
)

select *
from cte 
where avg_sales = (select max(avg_sales) from cte) or avg_sales = (select min(avg_sales) from cte);
