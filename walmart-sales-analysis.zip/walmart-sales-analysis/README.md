# Walmart Sales Analysis (2010–2012)

This project analyzes Walmart sales data across 45 stores in the US, focusing on sales trends, store performance, fuel price correlation, and holiday impact.

## 🔧 Tools Used
- **Pandas**: Data cleaning and preprocessing
- **SQL (MySQL)**: Extracting insights and aggregating results
- **Tableau**: Data visualization and dashboard creation

## 📊 Dashboard Preview

![Dashboard Screenshot](dashboard/dashboard_screenshot.png)

## 📁 Folder Structure

- `data/`: Raw dataset (CSV format) and cleaned version
- `notebooks/`: Jupyter notebook with data cleaning using pandas
- `sql_queries/`: SQL queries used for analysis
- `dashboard/`: Tableau workbook and dashboard image
- `project_summary.pdf`: Brief PDF summary (optional)

## 📌 Key Insights

- Total revenue across stores: $6.7B
- Store 20 performed the best overall
- Holidays have a slight positive impact on sales
- No strong correlation between fuel price and weekly sales
- Seen a significant dip in sales in 2012

## 🚀 How to Run
1. Open the `notebooks/walmart_sales_cleanup.ipynb` to see preprocessing steps.
2. Use the `sql_queries/sales_insights.sql` with MySQL for SQL-based analysis.
3. Open `dashboard/walmart_sales_dashboard.twb` in Tableau to view or modify the dashboard.

## 📬 Contact
Created by ATCHUDAN — aspiring Data Analyst.

